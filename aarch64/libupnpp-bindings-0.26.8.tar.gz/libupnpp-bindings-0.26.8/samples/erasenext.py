#!/usr/bin/python3
# Run a setNextAVTransportURI with sufficiently valid but unplayable data to cancel the last song in
# an AVT playlist (already sent to the renderer, so the only way is to replace nextURI).

import sys
import time
import upnpp

def debug(x):
   print("%s" % x, file = sys.stderr)
def usage():
   debug("Usage: erasenext.py devname")
   sys.exit(1)
   
if len(sys.argv) != 2:
   usage()
devname = sys.argv[1]

srv = upnpp.findTypedService(devname, "avtransport", True)

if not srv:
   debug("findTypedService failed")
   sys.exit(1)

uri = "http://192.2.0.2:0/song.mp3"
metadata = '<?xml version="1.0" encoding="utf-8"?><DIDL-Lite xmlns="urn:schemas-upnp-org:metadata-1-0/DIDL-Lite/" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:upnp="urn:schemas-upnp-org:metadata-1-0/upnp/" xmlns:dlna="urn:schemas-dlna-org:metadata-1-0/"><item id="abc" parentID="ab" restricted="1" searchable="0"><dc:title>a</dc:title><upnp:class>object.item.audioItem.musicTrack</upnp:class><res duration="0:0:0" size="0" bitrate="192000" sampleFrequency="44100" bitsPerSample="16" nrAudioChannels="2" protocolInfo="http-get:*:audio/mpeg:* ">http://192.2.0.2:0/song.mp3</res></item></DIDL-Lite>'

upnpp.runaction(srv, "SetNextAVTransportURI", ["0", uri, metadata])

time.sleep(1)
retdata = upnpp.runaction(srv, "GetMediaInfo", ["0"])
print(f"{retdata}")

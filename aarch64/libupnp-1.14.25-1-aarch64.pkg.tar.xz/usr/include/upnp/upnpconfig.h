/* -*- C -*- */
/*******************************************************************************
 *
 * Copyright (c) 2006 Rémi Turboult <r3mi@users.sourceforge.net>
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * * Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 * * Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 * * Neither name of Intel Corporation nor the names of its contributors
 * may be used to endorse or promote products derived from this software
 * without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL INTEL OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
 * OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 ******************************************************************************/

#ifndef UPNP_CONFIG_H
#define UPNP_CONFIG_H

/***************************************************************************
 * Library version
 ***************************************************************************/

/** The library version (string) e.g. "1.3.0" */
#undef UPNP_VERSION_STRING
#define UPNP_VERSION_STRING "17.2.5"

/** Major version of the library */
#undef UPNP_VERSION_MAJOR
#define UPNP_VERSION_MAJOR 17

/** Minor version of the library */
#undef UPNP_VERSION_MINOR
#define UPNP_VERSION_MINOR 2
#ifndef UPNP_VERSION_MINOR
#	define UPNP_VERSION_MINOR 0
#endif

/** Patch version of the library */
#undef UPNP_VERSION_PATCH
#define UPNP_VERSION_PATCH 5
#ifndef UPNP_VERSION_PATCH
#	define UPNP_VERSION_PATCH 0
#endif

/** The library version (numeric) e.g. 10300 means version 1.3.0 */
#define UPNP_VERSION \
	((UPNP_VERSION_MAJOR * 100 + UPNP_VERSION_MINOR) * 100 + \
		UPNP_VERSION_PATCH)

/***************************************************************************
 * Large file support
 ***************************************************************************/

/* #undef UPNP_LARGEFILE_SENSITIVE */

/***************************************************************************
 * Library optional features
 ***************************************************************************/

/*
 * The following defines can be tested in order to know which
 * optional features have been included in the installed library.
 */

/** Defined to 1 if the library has been compiled with client API enabled
 *  (i.e. configure --enable-client) */
#define UPNP_HAVE_CLIENT 1

/** Defined to 1 if the library has been compiled with device API enabled
 *  (i.e. configure --enable-device) */
#define UPNP_HAVE_DEVICE 1

/** Defined to 1 if the library has been compiled with integrated web server
 *  (i.e. configure --enable-webserver --enable-device) */
#define UPNP_HAVE_WEBSERVER 1

/** Defined to 1 if the library has been compiled with the SSDP part enabled
 *  (i.e. configure --enable-ssdp) */
#define UPNP_HAVE_SSDP 1

/** Defined to 1 if the library has been compiled with optional SSDP headers
 *  support (i.e. configure --enable-optssdp) */
#define UPNP_HAVE_OPTSSDP 1

/** Defined to 1 if the library has been compiled with the SOAP part enabled
 *  (i.e. configure --enable-soap) */
#define UPNP_HAVE_SOAP 1

/** Defined to 1 if the library has been compiled with the GENA part enabled
 *  (i.e. configure --enable-gena) */
#define UPNP_HAVE_GENA 1

/** Defined to 1 if the library has been compiled with helper API
 *  (i.e. configure --enable-tools) : <upnp/upnptools.h> file is available */
#define UPNP_HAVE_TOOLS 1

/** Defined to 1 if the library has been compiled with ipv6 support
 *  (i.e. configure --enable-ipv6) */
#define UPNP_ENABLE_IPV6 1

/** Defined to 1 if the library has been compiled with unspecified SERVER
 * header (i.e. configure --enable-unspecified_server) */
/* #undef UPNP_ENABLE_UNSPECIFIED_SERVER */

/** Defined to 1 if the library has been compiled with OpenSSL support
 *  (i.e. configure --enable-open_ssl) */
/* #undef UPNP_ENABLE_OPEN_SSL */

/** Defined to 1 if the library has been compiled to use blocking TCP socket
 * calls (i.e. configure --enable_blocking_tcp_connections) */
/* #undef UPNP_ENABLE_BLOCKING_TCP_CONNECTIONS */

/** Defined to 1 if the library has been compiled bind the miniserver socket
 * with SO_REUSEADDR (i.e. configure --enable_reuseaddr) */
#define UPNP_MINISERVER_REUSEADDR 1

#endif /* UPNP_CONFIG_H */

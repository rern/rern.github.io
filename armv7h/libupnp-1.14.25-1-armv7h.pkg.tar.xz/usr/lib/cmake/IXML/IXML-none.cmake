#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "IXML::Shared" for configuration "None"
set_property(TARGET IXML::Shared APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(IXML::Shared PROPERTIES
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/libixml.so.11.1.3"
  IMPORTED_SONAME_NONE "libixml.so.11"
  )

list(APPEND _cmake_import_check_targets IXML::Shared )
list(APPEND _cmake_import_check_files_for_IXML::Shared "${_IMPORT_PREFIX}/lib/libixml.so.11.1.3" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)

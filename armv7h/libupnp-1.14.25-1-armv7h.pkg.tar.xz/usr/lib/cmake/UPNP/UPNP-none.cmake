#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "UPNP::Shared" for configuration "None"
set_property(TARGET UPNP::Shared APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(UPNP::Shared PROPERTIES
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/libupnp.so.17.2.5"
  IMPORTED_SONAME_NONE "libupnp.so.17"
  )

list(APPEND _cmake_import_check_targets UPNP::Shared )
list(APPEND _cmake_import_check_files_for_UPNP::Shared "${_IMPORT_PREFIX}/lib/libupnp.so.17.2.5" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
